<?php

//
$functions = array(
    'block_question_status_get_quiz_wrongquestions' => array(
        'classpath' => '',
        'classname' => 'block_question_status\external',
        'methodname' => 'get_quiz_wrongquestions',
        'description' => 'Return list of all learners in the course',
        'type' => 'read',
         'ajax'        => true,
        'capabilities' => '',
    )
);